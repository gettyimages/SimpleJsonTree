﻿var simpleJsonTree = (function () {
  var createListItem = function () {
    return $("<li class='tree-list-item tree-item-closed'></li>");
  };

  var createButton = function () {
    return $("<span class='button'></span>");
  };

  var writeNode = function (object, target) {
    var listItem = createListItem();
    listItem.addClass("tree-branch");
    listItem.append(createButton());
    listItem.append(object.key);
    target.append(listItem);
    render(object.value, listItem);
  };

  var writeNodes = function (arrayKvp, target) {
    var i;
    var listItem = createListItem();
    listItem.addClass("tree-branch");
    listItem.append(createButton());
    listItem.append(arrayKvp.key);
    target.append(listItem);

    for (i = 0; i < arrayKvp.value.length; i += 1) {
      render(arrayKvp.value[i], listItem);
    }
  };

  var writeLeafNode = function (object, target) {
    var listItem = createListItem();
    listItem.addClass("tree-leaf");
    listItem.append("<label>" + object.key + ":</label><span>" + object.value + "</span>");
    target.append(listItem);
  };

  var readProperties = function (object) {
    var properties = [];
    for (var key in object) {
      value = object[key];
      properties.push({ key: key, value: value });
    }
    return properties;
  };

  var render = function (data, target) {
    var list = $("<ul class='tree-list'></ul>");
    target.append(list);

    var foo = readProperties(data);
    var i;
    for (i = 0; i < foo.length; i += 1) {
      handleType(foo[i], list);
    }
  };

  var handleType = function (object, target) {
    if (Array.isArray(object.value)) {
      writeNodes(object, target);
    }
    else if (typeof object.value === "object") {
      writeNode(object, target);
    } else {
      writeLeafNode(object, target);
    }
  };

  var setTreeBranchClass = function (branchItem) {
    if (branchItem.hasClass("tree-item-closed")) {
      branchItem.removeClass("tree-item-closed");
      branchItem.addClass("tree-item-open");
    } else {
      branchItem.removeClass("tree-item-open");
      branchItem.addClass("tree-item-closed");
    }
  };

  var toggle = function (e) {
    e.stopPropagation();
    $(e.target).parent().children("ul").toggle();
    setTreeBranchClass($(e.target).parent());
  };

  var init = function () {
    $(document).delegate(".tree-branch", "click", toggle);
  };

  return {
    render: function (data, target) {
      return render(data, target);
    },
    init: function () {
      return init();
    }
  };
})();

$(document).ready(function () {
  var data = {
    foo: "lorem",
    bar: "ipsum",
    baz: "dolor",
    foobar: {
      iam: "a nested object property"
    },
    barbaz: [
      {
        iam: "an object property nested in an array",
        andiam: [
          {
            yepiam: "a property nested deep in arrays and objects",
            andisuream: {
              anotherproperty: "nested even further down the hierarchy"
            }
          }
        ]
      },
      {
        iam: "another object property nested in an array"
      }
    ]
  };

  simpleJsonTree.render(data, $("#target"));
  simpleJsonTree.init();
});